import java.util.Iterator;
import java.util.Map;
import java.util.Set;


public class Student {
	private int stdit;
	private String stdname;
	private int stdmarks;
	private Map<String,String>Remarks;
	
	public int getStdit() {
		return stdit;
	}
	public void setStdit(int stdit) {
		this.stdit = stdit;
	}
	public String getStdname() {
		return stdname;
	}
	public void setStdname(String stdname) {
		this.stdname = stdname;
	}
	public int getStdmarks() {
		return stdmarks;
	}
	public void setStdmarks(int stdmarks) {
		this.stdmarks = stdmarks;
	}
void display()
{
	System.out.println(this.stdit);
	System.out.println(this.stdname);
	System.out.println(this.stdmarks);
	Set s=Remarks.entrySet();
	Iterator<String> itr =  s.iterator();
	while (itr.hasNext()) {
		System.out.println(itr.next());
	}
}
public Map<String, String> getRemarks() {
	return Remarks;
}
public void setRemarks(Map<String, String> remarks) {
	Remarks = remarks;
}


}
