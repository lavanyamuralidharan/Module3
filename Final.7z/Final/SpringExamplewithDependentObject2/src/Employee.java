
public class Employee {
private int empId;
private String empName;
private long esal;

private  Address add;
private taddress tadd;
 


public int getEmpId() {
    return empId;
}
public void setEmpId(int empId) {
    this.empId = empId;
}
public String getEmpName() {
    return empName;
}

public taddress getTadd() {
	return tadd;
}
public void setTadd(taddress tadd) {
	this.tadd = tadd;
}
public void setEmpName(String empName) {
    this.empName = empName;
}
public long getEsal() {
    return esal;
}
public void setEsal(long esal) {
    this.esal = esal;
}
public void display()
{
    System.out.println("Employee Id:"+empId);
    System.out.println("Employee Name:"+empName);
    System.out.println("Employee Sal:"+esal);
    System.out.println(add);
    System.out.println(tadd);
    
}
public Address getAdd() {
    return add;
}

public void setAdd(Address add) {
    this.add = add;
}
@Override
public String toString() {
	return "Employee [empId=" + empId + ", empName=" + empName + ", esal=" + esal + ", add=" + add + ", tadd=" + tadd
			+ "]";
}
public Employee(int empId, String empName, long esal, Address add, taddress tadd) {
	super();
	this.empId = empId;
	this.empName = empName;
	this.esal = esal;
	this.add = add;
	this.tadd = tadd;
}

public Employee() {
	// TODO Auto-generated constructor stub
}
 

}
