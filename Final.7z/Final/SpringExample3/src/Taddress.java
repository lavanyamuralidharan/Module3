
public class Taddress 
{

 

    
        private int hno1;
        private String colony1;
        private String city1;
        
        public int getHno1() {
            return hno1;
        }
        public void setHno1(int hno1) {
            this.hno1 = hno1;
        }
        public String getColony1() {
            return colony1;
        }
        public void setColony1(String colony1) {
            this.colony1 = colony1;
        }
        public String getCity1() {
            return city1;
        }
        public void setCity1(String city1) {
            this.city1 = city1;
        }
        @Override
        public String toString() {
            return "Address [hno1=" + hno1 + ", colony1=" + colony1 + ", city1=" + city1 + "]";
        }
        public Taddress(int hno1, String colony1, String city1) {
            super();
            this.hno1 = hno1;
            this.colony1 = colony1;
            this.city1 = city1;
        }
        
        
        

 

}
