
public class Student {
	private int stdit;
	private String stdname;
	private int stdmarks;
	public int getStdit() {
		return stdit;
	}
	public void setStdit(int stdit) {
		this.stdit = stdit;
	}
	public String getStdname() {
		return stdname;
	}
	public void setStdname(String stdname) {
		this.stdname = stdname;
	}
	public int getStdmarks() {
		return stdmarks;
	}
	public void setStdmarks(int stdmarks) {
		this.stdmarks = stdmarks;
	}
void display()
{
	System.out.println(this.stdit);
	System.out.println(this.stdname);
	System.out.println(this.stdmarks);
}
public Student(int stdit, String stdname, int stdmarks) {
	super();
	this.stdit = stdit;
	this.stdname = stdname;
	this.stdmarks = stdmarks;
}
public Student() {
	super();
	// TODO Auto-generated constructor stub
}
}
