import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
private int empId;
private String empName;
private long esal;
@Autowired
private  Address add;
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public long getEsal() {
	return esal;
}
public void setEsal(long esal) {
	this.esal = esal;
}
//public Address getAdd() {
//	return add;
//}
//
//public void setAdd(Address add) {
//	this.add = add;
//}
//public Employee(int empId, String empName, long esal, Address add) {
//	super();
//	this.empId = empId;
//	this.empName = empName;
//	this.esal = esal;
//	this.add = add;
//}

  public void display()
 {
	 System.out.println(empId);
	 System.out.println(empName);
	 System.out.println(esal);
	 System.out.println(add);
 }




 

}
