
public class Employee {
private int empId;
private String empName;
private long esal;
private  Address add;
private taddress tadd;
 


public int getEmpId() {
    return empId;
}
public void setEmpId(int empId) {
    this.empId = empId;
}
public String getEmpName() {
    return empName;
}/*public Employee() {
    // TODO Auto-generated constructor stub
}*/
/*public Employee(int empId, String empName, long esal) {
    super();
    this.empId = empId;
    this.empName = empName;
    this.esal = esal;
}*/
public void setEmpName(String empName) {
    this.empName = empName;
}
public long getEsal() {
    return esal;
}
public void setEsal(long esal) {
    this.esal = esal;
}
/*public void display()
{
    System.out.println("Employee Id:"+empId);
    System.out.println("Employee Name:"+empName);
    System.out.println("Employee Sal:"+esal);
    
}*/
public Address getAdd() {
    return add;
}
public void setAdd(Address add) {
    this.add = add;
}
@Override
public String toString() {
    return "Employee [empId=" + empId + ", empName=" + empName + ", esal=" + esal + ", add=" + add + "]";
}

 

}
